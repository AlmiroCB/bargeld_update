fun main(){
println(
    Euro(53054)
)
    println(Euro(333330))
}

