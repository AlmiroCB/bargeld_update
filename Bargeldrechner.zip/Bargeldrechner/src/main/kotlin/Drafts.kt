//     if (euro >= 1){
//         if (moneyMap.containsKey(euro.toDouble())) moneyMap.set(euro.toDouble(),+1)
//         else{
//             var rest:Int = 0
//             do {
//                 euro--
//                 rest ++
//             }
//             while (!moneyMap.containsKey(euro.toDouble()))
//             if (moneyMap.containsKey(rest.toDouble())) moneyMap.set(rest.toDouble(),+1)
//             else {
//                 var nextRest:Int = 0
//                 do {
//                     rest--
//                     nextRest++
//                 }
//                 while (!moneyMap.containsKey(rest.toDouble()))
//                 if (moneyMap.containsKey(nextRest.toDouble())) moneyMap.set(nextRest.toDouble(),+1)
//             }
//
//         }
//     }

//init {
////        var whole = (amount/ 100).toDouble()
////        var rest = (amount % 100).toDouble()
////        if (moneyMap.containsKey(amount.toDouble() / 100)){
////            moneyMap.set(amount.toDouble() / 100, +1)
////            moneyMap.filter { it.value != 0 }
////        }
////
////        if (euroMap.containsKey(whole)) moneyMap.set(whole,+1) else do {
////            whole
////        }
//}



//    fun splitMoney(){
//        if (amount / 100 >= 1 ){
//            val rest = amount%100
//            val euros = amount/ 100
//            if (rest != 0){
//            }
//            println("$euros€" + "$rest" +'c' )
//        }
//
//    }