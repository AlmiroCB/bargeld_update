import jdk.incubator.vector.VectorOperators.Operator

data class Euro(val amount: Int){
     var euro:Int = 0;
     var cent:Int = 0;


    var moneyMap = mutableMapOf<Double, Int>(
        500.0 to 0, 200.0 to 0, 100.0 to 0, 50.0 to 0, 20.0 to 0,
        10.0 to 0, 5.0 to 0, 2.0 to 0, 1.0 to 0,
        0.5 to 0, 0.2 to 0,0.1 to 0,
        0.05 to 0, 0.02 to 0,0.01 to 0
    )



    var euroMap = mutableMapOf<Double, String>(
        500.0 to "500€", 200.0 to "200€", 100.0 to "100€", 50.0 to "50€", 20.0 to "20€",
        10.0 to "10€", 5.0 to "5€", 2.0 to "2€", 1.0 to "1€",
        0.5 to "50c", 0.2 to "20c",0.1 to "10c",
        0.05 to "5c", 0.02 to "2c",0.01 to "1c"
    )
     init {
          euro = (amount/ 100)
          cent = (amount % 100)
          countEuro()
     }

     fun countEuro(){
         var whole = amount.toDouble()/100

         for (unit in moneyMap.keys.sortedDescending()){
             if (whole >= unit){
                 var count = (whole / unit).toInt()
                 moneyMap[unit] = count
                 whole -= count * unit

             }
         }
     }

    operator fun plus(euro: Euro): Euro {
        return Euro(this.amount+euro.amount)
    }

    override fun toString(): String {
        val result = "$euro $cent"
        var output:StringBuilder = StringBuilder();
        for ((key,value) in moneyMap)
        if (value > 0){
            output.append("${euroMap[key]} x$value\n")
        }
        return  output.toString()
    }
}



